#include<stdio.h>
#include<stdlib.h>

int main(){
	
	char F[501], G[501], H[501], c;
	int count[26] = {0}, i, j;
	FILE *f, *g, *h;
	
	scanf(" %s", F);
	scanf(" %s", G);
	scanf(" %s", H);
	f = fopen(F, "r");
	g = fopen(G, "r");
	h = fopen(H, "w");
	
	fscanf(f, "%c", &c);
	while(c!='\n'){
		count[c-'a']++;
		fscanf(f, "%c", &c);
	}
	
	fscanf(g, "%c", &c);
	while(c!='\n'){
		count[c-'a']++;
		fscanf(g, "%c", &c);
	}
	
	for(i=0; i<26; i++){
		for(j=0; j<count[i]; j++){
			fprintf(h, "%c", (char)('a'+i));
		}
	}
	
	fclose(f);
	fclose(g);
	fclose(h);
	
	return 0;
} 
