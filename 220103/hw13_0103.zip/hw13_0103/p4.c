#include <stdio.h>
#include <stdlib.h>

struct data {
	char name[100];
	int CP;
	int calculus;
	int probability;
};

void swap(struct data **s1, struct data **s2) {
	struct data *tmp;
	tmp = *s1;
	*s1 = *s2;
	*s2 = tmp;
}

void sort(int n, struct data **students){
	int i, j, s1, s2;
	for (i = 0; i < n; i++){ 
		for (j = 0; j < n - i - 1; j++) {
			s1 = students[j]->CP + students[j]->calculus + students[j]->probability;
			s2 = students[j+1]->CP + students[j+1]->calculus + students[j+1]->probability;
			if (s1 < s2)
				swap(&students[j], &students[j+1]);
		}
	}

	for(i = 0; i < n; i++){
		printf("\n%s %d %d %d", students[i]->name, students[i]->CP,
			students[i]->calculus, students[i]->probability);
	}
}

int main() {
	int n, i;
	scanf("%d", &n);
	struct data** students = (struct data**)malloc(sizeof(struct data*) * n);
	for (i = 0; i < n; i++){
		students[i] = (struct data*)malloc(sizeof(struct data));
		scanf("%s%d%d%d", &students[i]->name, &students[i]->CP,
		     &students[i]->calculus, &students[i]->probability);
	}
	sort(n, students);
	
	return 0;
}
