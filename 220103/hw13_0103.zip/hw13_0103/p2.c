#include<stdio.h>
#include<stdlib.h>

int main(){
	
	int a, b;
	char file[501];
	FILE *fp;
	
	scanf("%s", file);
	fp=fopen(file, "r");
	while((fscanf(fp, "%d %d", &a, &b)) !=  EOF){
		printf("%d\n", a+b);
	}
	fclose(fp);
	return 0;
} 
