#include<stdio.h>
#include<stdlib.h>

int main(){
	
	char file[501], c;
	FILE *fp;
	
	scanf("%s", file);
	fp=fopen(file, "w");
	scanf(" %c", &c);
	while(c !=  '\n'){
		fprintf(fp, "%c", c);
		//scanf("%c", &c);
	}
	fclose(fp);
	return 0;
} 
