#include<stdio.h>
#include<stdlib.h>

int main(){
	
	int N;
	char file[501];
	FILE *fp;
	
	scanf("%d\n", &N);
	while(N--){
		scanf(" %s", file);
		fp=fopen(file, "r");
		if (fp ==NULL){
			printf("%s opened failed\n", file);
		}
		else{
			printf("%s opened successfully\n", file);
		}
		fclose(fp);
	}
	
	return 0;
} 
