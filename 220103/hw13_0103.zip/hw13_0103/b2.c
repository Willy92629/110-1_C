#include<stdio.h>
#include<stdlib.h>

int main(){
	
	int count=0, flag=1;
	char c[100001], input;

	scanf("%c", &input);
	while(input !=  '\n'){
		if(input=='(' || input=='[' || input=='{'){
            c[count] = input;
            count++;
        }
        else{
            if(count <= 0){
            	flag=0;
            	break;
			}
            if(input==')'){
                if(c[count-1]!='('){
                    flag=0;
                    break;
                }
                else{
                    count--;
                }
            }
            if(input==']'){
                if(c[count-1]!='['){
                    flag=0;
                    break;
                }
                else{
                    count--;
                }
            }
            if(input=='}'){
                if(c[count-1]!='{'){
                    flag=0;
                    break;
                }
                else{
                    count--;
                }
            }
        }
    	scanf("%c", &input);
	}
	
	if(flag==0 || count>0){
		printf("No\n");
	}
	else{
		printf("Yes\n");
	}
	
	return 0;
} 
